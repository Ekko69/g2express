<?php

namespace App\Models;

class Onboarding extends NoDeleteBaseModel
{
    
}
