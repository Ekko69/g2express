<?php

namespace App\Traits;


trait FirebaseDBTrait
{
    
}
