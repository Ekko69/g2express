<?php

namespace App\Http\Livewire;


class ReviewLivewire extends BaseLivewireComponent
{

    public function render()
    {
        return view('livewire.reviews');
    }

}
