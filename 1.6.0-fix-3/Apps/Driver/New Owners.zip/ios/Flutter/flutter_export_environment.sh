#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/ambrosetemidayobako/Dev/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/ambrosetemidayobako/Dev/mobile-apps/Fuodz-delivery-boy"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.6.0"
export "FLUTTER_BUILD_NUMBER=41"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=false"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
