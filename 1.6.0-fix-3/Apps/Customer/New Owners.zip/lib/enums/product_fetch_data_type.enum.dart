enum ProductFetchDataType {
  NEW,
  FLASH,
  RANDOM,
  BEST
}
